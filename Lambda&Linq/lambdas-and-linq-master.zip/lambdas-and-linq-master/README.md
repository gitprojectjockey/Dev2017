# lambdas-and-linq
Code to help you learn the awesomeness of lambda expressions and LINQ in C#

These are the code samples that accompany my "Learn to Love Lambdas (and LINQ, Too!)" presentation and upcoming video series.

For more information visit http://www.jeremybytes.com/Demos.aspx#LLL
